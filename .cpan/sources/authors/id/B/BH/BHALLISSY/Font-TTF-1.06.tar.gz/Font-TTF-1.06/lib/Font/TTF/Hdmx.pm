package Font::TTF::Hdmx;

=head1 NAME

Font::TTF::Hdmx - Horizontal device metrics

=head1 DESCRIPTION

The table consists of an hash of device metric tables indexed by the ppem for
that subtable. Each subtable consists of an array of advance widths in pixels
for each glyph at that ppem (horizontally).

=head1 INSTANCE VARIABLES

Individual metrics are accessed using the following referencing:

    $f->{'hdmx'}{$ppem}[$glyph_num]

In addition there is one instance variable:

=over 4

=item Num

Number of device tables.

=back

=head2 METHODS

=cut

use strict;
use vars qw(@ISA);

@ISA = qw(Font::TTF::Table);


=head2 $t->read

Reads the table into data structures

=cut

sub read
{
    my ($self) = @_;
    $self->SUPER::read or return $self;

    my ($fh) = $self->{' INFILE'};
    my ($numg, $ppem, $i, $numt, $dat, $len);

    $numg = $self->{' PARENT'}{'maxp'}{'numGlyphs'};

    $fh->read($dat, 8);
    ($self->{'Version'}, $numt, $len) = unpack("nnN", $dat);
    $self->{'Num'} = $numt;

    for ($i = 0; $i < $numt; $i++)
    {
        $fh->read($dat, $len);
        $ppem = unpack("BBd_xml($conDC/    -i        o"ontext->1 NAME

elf->{' PARENT'}C;} = D<            2a sname--

 post--
Th ($sYelf-f) = @_selfpa clself;

   len@;
    $->{ file to output

=cut

sub out
{
    my ($sel(f, $fh) = @_;
   return $self;

    my ($fh) = $self->{' INFILE'};
    my->{'S'} = $ner'}(/^\d+$/,  my ($shipout) = ($statk("n", ${'Num'a)
  "\   "ch $3   f-f) =last, %nge, $delt);
 = -f) =lasbstr    { ve'a), $j);

    return $self-axp'}}->t#'} = +s));
   $context->{{'Ve(S'} =t, $len) = unpack->{'START'} : 0))t $map[$n$s->{'LOC'$i}}

=of-f) =l    ]1);
        }->{'ST;
        $s->{$k < $segs->'Ver'}));       #      i  $->{, $s->{'LOC'$i}}

=of-f) =l    ]1, $s'a), $j);
 $ppem = unpack(ends here
  ingize($base_loc))g inf:Preum  $seleir
emulates work   }
   ll tm    ity of eir
, many) o=cut

u
m
=heb theeen imphd readind LIts var  $f-$f-> (Platform 3, ingize        output8pack("BBd_xml($coglyph__do(&func)emorythe pptable con   at th &tab($ori @_;
  )(Platform 3,glyph__do       2a sname--

 unc)tance variable
toble) = defined $tVe(er'}(/^\d+$/, tk("n",();
    &
 unc(->{'LOC'$i}map su  $ppem = unpack("BBd_xml($coL_hinlyph> _dat>.

=cut

sub    eyles'020) -i        text->1 NAME

eas rtt     e foidie we;
    $self;
}
lyph>   

=head2 $t->XML_end($context, $tag, %attrs)

sub    eyles'020) xt, $depth)

Outputs Prep program as XML

=cut

si file to output

=cut

sub ouL_hinlyph> _n($g codori(s'020) x us'ARRAY'ndent'}/omg;
    $fh->prin NAME

e;
  ='  ey' = $context->{ ($self->{'Ver$eSel)'020)Platf    25'} ? 'coverage' : 'class')~ s/\n(?!$)/\n$depth$context".al'}{$' ', $s-'020)P[tf c) =ilasb4]1, $"= $contextf("$depth$context->{'inden NAME

'val'}{$gid});
    }
->{'text'});
        return $context;
    } else
    { return $self->SUPER::XML_end(@_); }
}

1;

=head1 BUGS

None known

=head1 AUTHOR

Martin Hosken L<http://scripts.sil.org/FontUtils>. 


=head1 LICENSING

Copyright (c) 1998-2016, SIL International (http://www.sil.org) 

This module is released under the terms of the Artistic License 2.0. 
For details, see the full text of the license in the file LICENSE.



=cut


